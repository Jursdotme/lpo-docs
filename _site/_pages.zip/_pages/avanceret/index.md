---
layout: page
title: "Avancerede funtioner"
permalink: /docs/avanceret/
---
{% include subpagelist.html %}
