---
layout: page
title: "Historie"
permalink: /docs/rediger-indhold/historie/
---


Page Builders historie browser er dit personlige sikkerhedsnet. Det giver dig mulighed for at hoppe frem og tilbage gennem ændringer og genoprette en version af din side, siden din sidste gemte version. Hvis du vil åbne historie browseren, klik på "Historik" på hovedsiden af PageBuilder værktøjslinjen.

Lad os sige, for eksempel, du kom til at lave en forkert ændring på din side. Det er ikke et problem; du kan se ændringen er i historien browseren. Klik på en begivenhed for at se, hvad siden lignede før denne begivenhed fandt sted.

![Widget Attributes]({{ site.baseurl }}/assets/PB34.png)

Du kan kontrollere, at du genskaber den korrekte version ved at se på eksemplet til højre. Når du er sikker, skal du klikke på "Gendan Version" for at indlæse denne version tilbage i Page Builder. Du vil også bemærke, at der er en "Version gendannet" begivenhed i historien nu. Dette giver dig mulighed for at gendanne siden, som den var før du har gendannet den gamle version. Så du kan altid få dine ændringer tilbage, hvis du beslutter dig for at beholde dem.
