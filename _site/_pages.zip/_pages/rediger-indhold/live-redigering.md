---
layout: page
title: "Live redigering"
permalink: /docs/rediger-indhold/live-redigering/
---


Live Editor er en funktion som giver dig en live forhåndsvisning af din side, som du kan redigere i live. Klik på Live Editor i værktøjslinjen for at starte værktøjet.

![Widget Attributes]({{ site.baseurl }}/assets/PB31.png)

Dette er den vigtigste interface til Live Editor.

![Widget Attributes]({{ site.baseurl }}/assets/PB32.png)

Der er en liste over de widgets du har i din side til venstre og en live forhåndsvisning af dit indhold til højre. Live Editor fremhæver en widget, når du svæver over det enten i indholdsoversigten eller det vigtigste eksempel på dit indhold.

![Widget Attributes]({{ site.baseurl }}/assets/PB33.png)

Hvis du klikker på en widget enten i live visningen, eller i indholdsoversigten, åbnes den Widgets dialogboks, som du skal bruge. Du kan foretage dine ændringer, og klikke på udført for at gemme disse ændringer.
