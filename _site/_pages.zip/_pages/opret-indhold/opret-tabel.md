---
layout: page
title: Opret Tabel
permalink: /docs/opret-indhold/opret-tabel/
---
TablePress giver dig mulighed for nemt at oprette og administrere flotte tabeller. Du kan integrere tabellerne i indlæg, sider eller tekst widgets med en simpel Shortcode. Tabel data kan redigeres i et excel-lignende interface, så ingen kodning er nødvendig. Tabeller kan indeholde alle typer af data, selv formler, vil blive evalueret.

Et ekstra JavaScript bibliotek tilføjer funktioner som sortering, paginering, filtrering og mere for besøgende. Tabeller kan importeres og eksporteres fra / til Excel, CSV, HTML, og JSON-filer.

For at oprette en tabel
