---
layout: page
title: "Links"
permalink: /docs/basis-guides/links/
---

Links er en af de allerbedste funktioner på nettet. Husk at linke til andre relevante sider hos dig selv eller andre steder på nettet. Det bliver alle glade for.

## Lav tekst om til link

Start med at markere den tekst, der skal blive til et link. Klik herefter på symbolet med lænken i værktøjslinjen. Det åbner vinduet Indsæt/rediger link.

URL: Vil du linke til en anden hjemmeside skriver du web-adressen her.

Titel er teksten, der dukker frem, når man kører over linket med musen. Det er bedst med en relevant titel med gode nøgleord, søgemaskinerne er glade for det.

![Widget Attributes]({{ site.baseurl }}/assets/wp-guide-add-inline-link.gif)

## Oversigt med eget indhold

Linker du til et sted på din egen hjemmeside, behøver du ikke kende www-adressen. Du kan i stedet finde det på oversigten nedenunder. Er den ikke åben, så klik på Eller link til... Find og marker det sted, du vil linke til. Klik til sidst på knappen Tilføj link. Så er det klar til brug, når du opdaterer.

Hvis du senere vil redigere det samme link, markerer du og klikker du på lænke-ikonet igen. Vil du slette et link, klikker du på Fjern link i værktøjslinjen.

Bedre metode til pdf
Du kan i princippet bruge denne metode til pdf-filer. Så skal du skrive hele adressen ind under URL. Det er dog langt lettere i stedet at bruge knappen Tilføj medier.
