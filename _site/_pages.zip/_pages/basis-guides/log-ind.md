---
layout: page
title: Log ind på din Wordpress-side
permalink: /docs/basis-guides/log-ind/
---
For at arbejde på din hjemmeside skal du først logge ind på administrationsdelen.

Du har sikkert et direkte link, men ellers er adressen sandsynligvis: www.dinhjemmeside.dk/wp-admin

Indtast dit brugernavn og den adgangskode, du har fået. Vær opmærksom på store eller små bogstaver.

Når du er færdig med at arbejde på din hjemmeside, kan du logge ud øverst til højre i kontrolpanelet.

![Widget Attributes]({{ site.baseurl }}/assets/logind-wpmanual.png)
