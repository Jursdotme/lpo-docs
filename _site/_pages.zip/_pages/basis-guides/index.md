---
layout: page
title: Basis Guides
permalink: /docs/basis-guides/
---

{% include subpagelist.html %}

Sådan opdaterer du din hjemmeside i Wordpress: Dette er en manual til de mest grundlæggende ting, så du selv kan redigere indholdet og lægge nyt på din hjemmeside.
