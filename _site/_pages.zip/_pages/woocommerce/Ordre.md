---
layout: page
title: Woocommerce Ordre
permalink: /docs/woocommerce/ordre/
---

## **1.** Ordre mail

Normalvis vil de modtage en e-mail når der gennemføres en ny ordre i systemet. Her står de mest nødvendige data, ved at klikke på Ordre nr. bliver man automatisk blive viderestillet direkte til den pågældende ordre i webshop-administration (kræver login).

![]({{ site.baseurl }}/assets/ordre-mail.png)

_Det anbefales dog at tjekke sin webshop-administration med jævne mellemrum, for at sikre sig der ikke ligger afventende ordre hvor ordremail er endt i spam/junk mappen._

## **2.** Administration

Tilgå webshop-administration via. www.ditdomænenavn.dk**/wp-admin/** (kræver login).

![]({{ site.baseurl }}/assets/ordre-wp-admin.png)

Tilgå dine ordre via. menupunktet **"WooCommerce➜Ordrer"**, tryk på ordre nr. for den pågældende ordre du ønsker.

![]({{ site.baseurl }}/assets/ordre-nav.png)


## **3.** Tjek ordre data i webshop-administration

Gennemtjek den valgte ordre, tjek at adresser er korrekt udfyldte fra kundens side, at beløbet stemmer overens og varen er på lager.

![]({{ site.baseurl }}/assets/ordre-check-wp.png)

## **4.** Tjek ordre data i betalings-gateway

Tilgå din betalings-gateway via.**[https://betaling.curanet.dk/](https://betaling.curanet.dk/)** (kræver login).

![]({{ site.baseurl }}/assets/ordre-pg.png)

Tjek at ordren med samme ordre nr. eksisterer, og at beløb stemmer overens med det i webshop-administrationen.

![]({{ site.baseurl }}/assets/ordre-check-pg.png)

## **5.** Levering

Det er nu tid til du skal pakke og sende din varer afsted til en forhåbentlig forventningsfuld kunde.

## **6.** Gennemfør ordre i betalings-gateway

Tilgå din betalings-gateway som i [pkt. 4](#section_4)

![]({{ site.baseurl }}/assets/ordre-pg.png)

Tryk på det grønne flueben udfor det pågældende ordre nr. Pengene vil nu blive hævet på kunden kreditkort, og vil være overført i løbet af få bankdage.

![]({{ site.baseurl }}/assets/ordre-check-pg.png)

## **7.** Gennemfør ordre i webshop-administration

Vælg din ordre som i [pkt. 3](#section_3), vælg **"Ordrestatus➜Gennemført"**, og tryk på gem ordre.

Kunden vil nu modtage en email der informere om ordrens gennemførsel.

![]({{ site.baseurl }}/assets/ordre-data.png)
