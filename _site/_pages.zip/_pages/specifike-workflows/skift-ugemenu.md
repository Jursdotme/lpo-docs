---
layout: page
title: Skift Ugemenu
permalink: /docs/specifike-workflows/skift-ugemenu/
---
For at skifte ugens menu, skal du først logge ind, hvorefter du skal klikke på **Kantine** i menuen til højre. Det bringer dig ind på siden, hvor brugeren kan se ugens menu. Det er indholdet bag den grønne knap, der skal skiftes.

![Menu](http://lpo.dk/brugerguide/img/menu.PNG)

Oppe i toppen ses en værktøjslinje, hvor du skal klikke på knappen **Rediger side**. Det åbner den side i administrationen, hvor ugens menu skal skiftes.

![Administration](http://lpo.dk/brugerguide/img/admin.PNG)

Her ses sidens administration, og al teksten er oprettet inde i den widget/kasse, der hedder **SiteOrigin Editor**, som også er markeret med gul. Den skal åbnes ved at klikke på det, der er markeret med gult eller ved at trykke **Rediger** ude til højre.

![Pagebuilder](http://lpo.dk/brugerguide/img/pagebuilder.PNG)

Du har nu åbnet den editor, hvor resten af arbejdet skal gøres. Vær sikker på, at det er **Visuel**, der er aktiveret i højre hjørne. Du skal nu markere og slette knappen med ugens menu. Nu skulle markøren blinke der, hvor der før var en knap. Tryk nu på knappen **Tilføj medier** oppe i venstre hjørne.

![Editor](http://lpo.dk/brugerguide/img/editor.PNG)

Du får nu vist mediebiblioteket, hvor du kan trykke **Upload filer** for at oploade ugens menu (Tip: Du kan trække filen fra computeren ind i mediebiblioteket for at uploade). Sørg herefter for, at den korrekte fil er markeret med en blå ramme.

![Mediebibliotek](http://lpo.dk/brugerguide/img/mediebib.PNG)

Til venstre i samme dialogboks, skal du skrive linkets **titel**. Det er den tekst, der vises i den grønne knap. Du skal herefter trykke **Indsæt på siden**.

![Indsæt](http://lpo.dk/brugerguide/img/indsaet.PNG)

Nu skulle der gerne stå et grønt link med den titel, du har valgt. Sæt nu markøren et sted på linket, så du får vist den grå værktøjslinje, som du kan ser herunder. Klik på blyantet og derefter på tandhjulet, så kan du sætte flueben i feltet **Åbn link i ny fane**. Tryk herefter på **Opdater**.

![Markér](http://lpo.dk/brugerguide/img/marker.PNG)

Uden at flytte markøren skal du nu vælge **Formater** og scrolle ned og vælg **Brand button**. Linket fremstår nu som en grøn knap. Klik nu på **Udført** nede i højre hjørne.

![Brand button](http://lpo.dk/brugerguide/img/brand.PNG)

Før ændringerne træder i kraft, skal du klikke på den røde knap **Opdater**, der er i sektionen til højre. Du har nu skiftet ugens menu.

![Opdater](http://lpo.dk/brugerguide/img/opdater.PNG)
